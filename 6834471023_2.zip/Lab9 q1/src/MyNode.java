public class MyNode {
    private Object data;
    private MyNode next;
    public MyNode(Object o,MyNode n){
        data = o;
        next = n;
    }
    public void setData(Object n){
        data = n;
    }
    public void setNext(MyNode n){
        next = n;
    }
    public Object getData(){
        return data;
    }
    public MyNode getNext(){
        return next;
    }
}
