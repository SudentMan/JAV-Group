    public class Truck extends Car {
        private double load;
        private double maxLoad;

        public  Truck(double gas, double gasRate,double maxLoad,double load){
            super(gas,gasRate);
            this.load = load;
            this.maxLoad = maxLoad;
        }
        @Override
        public void drive(double distance){
            double baseUse = distance / getEfficiency();
            if (load > maxLoad){
            }
            else{
                if (load < 1)
                    baseUse = baseUse;
                else if (load <= 10)
                    baseUse *= 1.10;
                else if (load <= 20)
                    baseUse *= 1.20;
                else
                    baseUse *= 1.30;
            }
            if (baseUse > getGas()) {
                System.out.println("You cannot drive too far, please add gas");
            } else {
                setGas(getGas() - baseUse);
            }
        }
    }
