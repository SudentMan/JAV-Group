public interface Collection {
    public void add(Object n);
    public boolean contain(Object n);
    public boolean isEmpty();
    public int size();
}