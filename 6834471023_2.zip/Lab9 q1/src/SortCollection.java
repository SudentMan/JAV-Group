public class SortCollection implements Collection{
    private MyNode first;
    private int size;
    public SortCollection(){
        first = null;
        size = 0;
    }
    public void add(Object n){
        if (!contain(n)) {
            System.out.println("Add Value: " + n);
            if(isEmpty()){
                first = new MyNode(n,first);
                size++;}
            else {
                MyNode c1 = first, c2 = null;
                int a = (int)c1.getData(),v = (int)n;
                if (a > v ){
                    first = new MyNode(n,first);
                }
                else {int count = 0;
                    while (c1 != null && a < v){
                        c2 = c1;
                        c1 = c1.getNext();
                        if(c1 != null) {
                            a = (int) c1.getData();
                        }
                        count++;
                    }

                    if (count!= 0)
                        System.out.println("count: "+count);
                    MyNode tmp = new MyNode(n,c1);
                    c2.setNext(tmp);
                }
            }
        }
        else{
            System.out.println(n + " has already exited in List");
            return;
        }

    }
    public boolean contain(Object n){
        MyNode start = first;
        while (start != null && !(start.getData().equals(n))){
            start = start.getNext();
        }
        return start != null;
    }
    public boolean isEmpty(){
        return size == 0;
    }
    public int size(){
        return size;
    }
    public void printList(){
        MyNode start = first;
        while (start != null){
            System.out.print(start.getData()+" ");
            start = start.getNext();
        }
        System.out.println();
        System.out.println("_______________________________");
    }
    public void remove(Object n){
        System.out.println("Remove Value: "+n);
        if(isEmpty()){
            System.out.println("Not Found");
            return;
        }
        else{
            MyNode c1 = first,c2 = null;
            int a = (Integer) c1.getData(), v = (Integer) n;
            int count = 0;
            while(c1!=null && a < v){
                c2 = c1;
                c1 = c1.getNext();
                if (c1 != null)
                    a = (Integer) c1.getData();
                count++;
            }
            if(a == v && c2 != null && c1 != null){
                MyNode m = c1.getNext();
                c2.setNext(m);
                System.out.println("count: "+count);
            }
            else if(a == v && c2 == null){
                first = first.getNext();
                System.out.println("count: "+count);
            }
            else {
                System.out.println("Not Found");
                System.out.println("count: " + count);
            }
        }
    }
}
