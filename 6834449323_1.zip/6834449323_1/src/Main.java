import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);

        Double total = 0.0;
        int total_c = 0;

        System.out.println("Enter course ID, credit and grade; or X to terminate");
        while (true){
            String ID = kb.next();

            if(ID.equalsIgnoreCase("x"))break;

            int numgit = kb.nextInt();
            String ABCD = kb.next();

            Double GRADE = 0.0;
            switch (ABCD){
                case "A" : GRADE = 4.0;break;
                case "B+" : GRADE = 3.5;break;
                case "B" : GRADE = 3.0;break;
                case "C+" : GRADE = 2.5;break;
                case "C" : GRADE = 2.0;break;
                case "D+" : GRADE = 1.5;break;
                case "D" : GRADE = 1.0;break;
                case "F" : GRADE = 0.0;break;
            }
            total += GRADE * numgit;
            total_c += numgit;

        }
        double XX = total/total_c;
        System.out.printf("GPA = %.2f ", XX);

    }
}