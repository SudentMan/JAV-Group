public class Main{
    public static void main(String[] args) {
        SortCollection list = new SortCollection();
        Integer ob1 = new Integer(20);
        Integer ob2 = new Integer(30);
        Integer ob3 = new Integer(15);
        Integer ob4 = new Integer(25);
        Integer ob5 = new Integer(30);
        Integer ob6 = new Integer(40);
        Integer ob7 = new Integer(28);
        Integer ob8 = new Integer(35);
        list.add(ob1);
        list.printList();
        list.add(ob2);
        list.printList();
        list.add(ob3);
        list.printList();
        list.add(ob4);
        list.printList();
        list.add(ob5);
        list.add(ob6);
        list.printList();
        System.out.println(" Is " + ob2 + " in the List? ");
        boolean a = list.contain(ob2);
        System.out.println(a);
        System.out.println(" Is " + ob7 + " in the List? ");
        boolean b = list.contain(ob7);
        System.out.println(b);
        list.remove(ob3);
        list.printList();
        list.remove(ob4);
        list.printList();
        list.remove(ob8);
    }
}