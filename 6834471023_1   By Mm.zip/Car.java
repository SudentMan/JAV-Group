public class Car {
    private double Gas = 0;
    private double GasRate = 0;
    private double UseGas = 0;
    public Car(double gas, double gasRate){
        Gas = gas;
        GasRate = gasRate;
    }
    public void drive(double distance){
        if(distance/GasRate <= Gas) {
            UseGas = distance/GasRate;
            Gas -= UseGas;
        }
        else System.out.println("You cannot drive too far please add gas");
    }
    public void setGas(double amount){
        Gas = amount;
    }
    public double getGas(){
        return Gas;
    }
    public double getEfficiency(){
        return GasRate;
    }
    public void addGas(double amount){
        Gas += amount;
    }
}

