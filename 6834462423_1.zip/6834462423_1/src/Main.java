import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double gpa;
        String grade;
        double score = 0;
        double totalScore = 0;
        double totalCredit = 0;

        while(true){
        String line = sc.nextLine().trim();
        if(line.equals("X")){
            break;
        }
        else{
            String[] parts = line.split(" ");
            if(parts.length != 3){
                continue;
            }
            String course = parts[0];
            int credit = Integer.parseInt(parts[1]);
            grade = parts[2];

            switch(grade){
                case "A":
                    score = 4.0;
                    break;
                case "B+":
                    score = 3.5;
                    break;
                case "B":
                    score = 3.0;
                    break;
                case "C+":
                    score = 2.5;
                    break;
                case "C":
                    score = 2.0;
                    break;
                case "D+":
                    score = 1.5;
                    break;
                case "D":
                    score = 1.0;
                    break;
                default:
                    score = 0.0;
                    break;

            }

            totalScore += score * credit;
            totalCredit += credit;

        }

        }
        if(totalCredit > 0) {
            gpa = totalScore / totalCredit;
            System.out.printf("GPA = %.2f\n", gpa);
        }
        else{
            System.out.print("error try again na ja!");
        }

}
}